package data

// Contact consists of contact information
var Contact = map[string][]string{
	"phone": {"###-###-####", "(###)###-####", "1-###-###-####", "###.###.####"},
}
