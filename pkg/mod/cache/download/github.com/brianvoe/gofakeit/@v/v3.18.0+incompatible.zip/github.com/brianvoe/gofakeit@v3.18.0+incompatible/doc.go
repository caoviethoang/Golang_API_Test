/*
Package gofakeit is a random data generator written in go

Every function has an example and a benchmark

See the full list here https://godoc.org/github.com/brianvoe/gofakeit

80+ Functions!!!
*/
package gofakeit
